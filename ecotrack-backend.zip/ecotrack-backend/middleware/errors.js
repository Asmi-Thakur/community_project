// Centralized error handler. Keeps route handlers free of repetitive
// try/catch boilerplate when used together with asyncHandler below.

class ApiError extends Error {
  constructor(statusCode, message, details) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

// Wraps an async route handler so rejected promises are forwarded to
// Express's error-handling middleware instead of crashing the process.
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: 'Not found', path: req.originalUrl });
}

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const statusCode = err.statusCode || 500;

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'One of your files is too large.' });
  }
  if (err.code === 'LIMIT_UNEXPECTED_FILE') {
    return res.status(400).json({ error: 'Too many files, or unexpected file field.' });
  }
  // Postgres unique violation
  if (err.code === '23505') {
    return res.status(409).json({ error: 'That record already exists.' });
  }
  // Postgres check constraint violation (e.g. invalid enum-like value)
  if (err.code === '23514') {
    return res.status(400).json({ error: 'Invalid value provided.', details: err.detail });
  }

  if (statusCode >= 500) {
    console.error(err);
  }

  res.status(statusCode).json({
    error: err.message || 'Internal server error',
    ...(err.details ? { details: err.details } : {}),
  });
}

module.exports = { ApiError, asyncHandler, notFoundHandler, errorHandler };
