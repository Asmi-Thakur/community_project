// Runs db/schema.sql against the configured PostgreSQL database.
// Usage: npm run migrate
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { pool } = require('./pool');

async function migrate() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const sql = fs.readFileSync(schemaPath, 'utf8');

  console.log('Running migrations from db/schema.sql ...');
  try {
    await pool.query(sql);
    console.log('✅ Migration complete. Tables are up to date.');
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

migrate();
