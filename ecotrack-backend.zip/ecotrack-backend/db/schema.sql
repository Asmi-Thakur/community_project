-- EcoTrack Goregaon — database schema
-- Run via: npm run migrate

-- ============================================================
-- ENUM-like check constraints are used instead of native ENUM
-- types so they can be altered later without type-migration pain.
-- ============================================================

CREATE TABLE IF NOT EXISTS localities (
  id            SERIAL PRIMARY KEY,
  name          TEXT NOT NULL UNIQUE,
  lat           DOUBLE PRECISION NOT NULL,
  lon           DOUBLE PRECISION NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0,
  active        BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS hotspots (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT NOT NULL,
  severity    TEXT NOT NULL CHECK (severity IN ('high', 'med')),
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS campaigns (
  id                SERIAL PRIMARY KEY,
  title             TEXT NOT NULL,
  organizer         TEXT NOT NULL,
  status            TEXT NOT NULL CHECK (status IN ('active', 'upcoming', 'completed', 'cancelled')) DEFAULT 'upcoming',
  event_date        DATE NOT NULL,
  start_time        TIME,
  end_time          TIME,
  address           TEXT NOT NULL,
  coordinator_phone TEXT,
  volunteers_needed INTEGER,
  volunteers_registered INTEGER NOT NULL DEFAULT 0,
  register_url      TEXT,
  map_url            TEXT,
  open_to_all        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- People who register interest for a campaign through our own API
-- (separate from external Google Form registrations, which we don't control).
CREATE TABLE IF NOT EXISTS campaign_registrations (
  id            SERIAL PRIMARY KEY,
  campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  contact       TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reports (
  id                SERIAL PRIMARY KEY,
  location_name     TEXT NOT NULL,
  landmark          TEXT,
  pollution_type    TEXT NOT NULL,
  severity          TEXT NOT NULL CHECK (severity IN ('low', 'med', 'high')),
  description       TEXT,
  reporter_name     TEXT,
  reporter_contact  TEXT,
  status            TEXT NOT NULL CHECK (status IN ('pending', 'verified', 'in_progress', 'resolved', 'rejected')) DEFAULT 'pending',
  lat               DOUBLE PRECISION,
  lon               DOUBLE PRECISION,
  ip_hash           TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS report_photos (
  id          SERIAL PRIMARY KEY,
  report_id   INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  filename    TEXT NOT NULL,
  original_name TEXT,
  mime_type   TEXT NOT NULL,
  size_bytes  INTEGER NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workshop_requests (
  id            SERIAL PRIMARY KEY,
  society_name  TEXT NOT NULL,
  contact_name  TEXT NOT NULL,
  contact_email TEXT,
  contact_phone TEXT,
  preferred_date DATE,
  notes         TEXT,
  status        TEXT NOT NULL CHECK (status IN ('new', 'scheduled', 'completed', 'cancelled')) DEFAULT 'new',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_campaigns_status_date ON campaigns(status, event_date);
CREATE INDEX IF NOT EXISTS idx_report_photos_report_id ON report_photos(report_id);
CREATE INDEX IF NOT EXISTS idx_hotspots_active ON hotspots(active);

-- Keep updated_at fresh automatically
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_reports_updated_at ON reports;
CREATE TRIGGER trg_reports_updated_at BEFORE UPDATE ON reports
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_campaigns_updated_at ON campaigns;
CREATE TRIGGER trg_campaigns_updated_at BEFORE UPDATE ON campaigns
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_hotspots_updated_at ON hotspots;
CREATE TRIGGER trg_hotspots_updated_at BEFORE UPDATE ON hotspots
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
