// Seeds the database with the same content that was hardcoded in the
// original frontend (localities, hotspots, campaigns) so the site keeps
// working exactly as before, but now from the database.
// Usage: npm run seed
require('dotenv').config();
const { pool } = require('./pool');

const LOCALITIES = [
  { name: 'Goregaon East', lat: 19.1663, lon: 72.8526, display_order: 1 },
  { name: 'Goregaon West', lat: 19.1604, lon: 72.8445, display_order: 2 },
  { name: 'Aarey Colony', lat: 19.1763, lon: 72.8714, display_order: 3 },
  { name: 'Oshiwara', lat: 19.1530, lon: 72.8330, display_order: 4 },
  { name: 'Film City Road', lat: 19.1710, lon: 72.8600, display_order: 5 },
  { name: 'Malad West', lat: 19.1862, lon: 72.8484, display_order: 6 },
  { name: 'Kandivali East', lat: 19.2041, lon: 72.8615, display_order: 7 },
  { name: 'Andheri West', lat: 19.1275, lon: 72.8347, display_order: 8 },
];

const HOTSPOTS = [
  {
    name: 'Aarey Colony — International Road Litter',
    description: 'Plastic waste and food debris along the main road corridor near Aarey Milk Colony.',
    severity: 'high',
  },
  {
    name: 'Oshiwara River Bank — Plastic Clogging',
    description: 'Plastic waste accumulation blocking the natural river flow and causing drainage issues.',
    severity: 'high',
  },
  {
    name: 'WEH Metro Junctions — Dust & Debris',
    description: 'Construction dust and debris accumulation near Western Express Highway metro stations.',
    severity: 'med',
  },
  {
    name: 'Link Road Industrial Pockets',
    description: 'Industrial waste and exhaust near Goregaon East link road commercial zones.',
    severity: 'med',
  },
];

const CAMPAIGNS = [
  {
    title: 'Aarey Forest Clean-Up Drive',
    organizer: 'Earth5R',
    status: 'active',
    event_date: '2026-06-21',
    start_time: '07:00',
    end_time: '10:00',
    address: 'Aarey Milk Colony Gate No. 2, Goregaon East, Mumbai 400065',
    coordinator_phone: '+919876543210',
    volunteers_needed: 25,
    volunteers_registered: 12,
    register_url: 'https://docs.google.com/forms/d/e/1FAIpQLSfRad61woTZu24SVTiP5c19MCxkh9Nwj5m_m9GhPQUNgiiftA/viewform?usp=header',
    open_to_all: false,
  },
  {
    title: 'Jallosh Coastal Clean-Up Drive',
    organizer: 'Project Mumbai',
    status: 'upcoming',
    event_date: '2026-06-28',
    start_time: '06:30',
    end_time: '09:30',
    address: 'Versova Beach Parking Lot, Andheri West, Mumbai 400061',
    coordinator_phone: '+919876501234',
    volunteers_needed: 50,
    volunteers_registered: 8,
    register_url: 'https://docs.google.com/forms/d/e/1FAIpQLScT5Bg3nO4hz_8Oov3rBMi45OaL6nkvok1NahXNwFlqKpDMNQ/viewform?usp=publish-editor',
    open_to_all: false,
  },
  {
    title: 'Oshiwara River Bank Restoration',
    organizer: 'Goregaon Green Warriors',
    status: 'upcoming',
    event_date: '2026-07-06',
    start_time: '08:00',
    end_time: '12:00',
    address: 'Oshiwara River, near Film City Road, Goregaon West, Mumbai 400104',
    coordinator_phone: '+918591073889',
    volunteers_needed: 30,
    volunteers_registered: 5,
    register_url: 'https://docs.google.com/forms/d/e/1FAIpQLSfRad61woTZu24SVTiP5c19MCxkh9Nwj5m_m9GhPQUNgiiftA/viewform?usp=header',
    open_to_all: false,
  },
  {
    title: 'Goregaon West Plastic-Free Walk',
    organizer: 'Mumbai CleanCity NGO',
    status: 'active',
    event_date: '2026-06-21', // "Every Sunday, ongoing" — represented as next occurrence
    start_time: '07:30',
    end_time: '09:00',
    address: 'Oberoi Mall Gate, S.V. Road, Goregaon West, Mumbai 400104',
    coordinator_phone: '+919820012345',
    volunteers_needed: null,
    volunteers_registered: 0,
    register_url: 'https://docs.google.com/forms/d/e/1FAIpQLScT5Bg3nO4hz_8Oov3rBMi45OaL6nkvok1NahXNwFlqKpDMNQ/viewform?usp=publish-editor',
    map_url: 'https://maps.google.com/?q=Oberoi+Mall+Goregaon+West+Mumbai',
    open_to_all: true,
  },
];

async function seed() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    console.log('Seeding localities...');
    for (const l of LOCALITIES) {
      await client.query(
        `INSERT INTO localities (name, lat, lon, display_order)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (name) DO UPDATE SET lat = $2, lon = $3, display_order = $4`,
        [l.name, l.lat, l.lon, l.display_order]
      );
    }

    console.log('Seeding hotspots...');
    const { rows: existingHotspots } = await client.query('SELECT COUNT(*)::int AS count FROM hotspots');
    if (existingHotspots[0].count === 0) {
      for (const h of HOTSPOTS) {
        await client.query(
          `INSERT INTO hotspots (name, description, severity) VALUES ($1, $2, $3)`,
          [h.name, h.description, h.severity]
        );
      }
    } else {
      console.log('  hotspots table already has data, skipping.');
    }

    console.log('Seeding campaigns...');
    const { rows: existingCampaigns } = await client.query('SELECT COUNT(*)::int AS count FROM campaigns');
    if (existingCampaigns[0].count === 0) {
      for (const c of CAMPAIGNS) {
        await client.query(
          `INSERT INTO campaigns
            (title, organizer, status, event_date, start_time, end_time, address,
             coordinator_phone, volunteers_needed, volunteers_registered,
             register_url, map_url, open_to_all)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
          [
            c.title, c.organizer, c.status, c.event_date, c.start_time, c.end_time, c.address,
            c.coordinator_phone, c.volunteers_needed, c.volunteers_registered,
            c.register_url, c.map_url || null, c.open_to_all,
          ]
        );
      }
    } else {
      console.log('  campaigns table already has data, skipping.');
    }

    await client.query('COMMIT');
    console.log('✅ Seed complete.');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌ Seed failed:', err.message);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
