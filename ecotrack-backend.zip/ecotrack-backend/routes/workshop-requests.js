const express = require('express');
const { query } = require('../db/pool');
const { asyncHandler, ApiError } = require('../middleware/errors');

const router = express.Router();

// POST /api/workshop-requests — request a free composting workshop.
// This backs an upgrade path for the "Request a Workshop via Email" mailto
// link on the Composting tab, in case that becomes a real form later.
router.post('/', asyncHandler(async (req, res) => {
  const { societyName, contactName, contactEmail, contactPhone, preferredDate, notes } = req.body || {};

  if (!societyName || !societyName.trim()) {
    throw new ApiError(400, 'Society / building name is required.');
  }
  if (!contactName || !contactName.trim()) {
    throw new ApiError(400, 'Contact name is required.');
  }
  if (!contactEmail && !contactPhone) {
    throw new ApiError(400, 'Please provide an email or phone number so we can reach you.');
  }

  const { rows } = await query(
    `INSERT INTO workshop_requests
      (society_name, contact_name, contact_email, contact_phone, preferred_date, notes)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, created_at`,
    [
      societyName.trim(),
      contactName.trim(),
      contactEmail ? contactEmail.trim() : null,
      contactPhone ? contactPhone.trim() : null,
      preferredDate || null,
      notes ? notes.trim() : null,
    ]
  );

  res.status(201).json({
    message: 'Workshop request received. The Green Warriors team will contact you soon.',
    request: rows[0],
  });
}));

module.exports = router;
