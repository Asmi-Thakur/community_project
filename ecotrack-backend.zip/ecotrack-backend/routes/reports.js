const express = require('express');
const crypto = require('crypto');
const { query, withTransaction } = require('../db/pool');
const { asyncHandler, ApiError } = require('../middleware/errors');
const { uploadReportPhotos } = require('../middleware/upload');

const router = express.Router();

const VALID_SEVERITIES = new Set(['low', 'med', 'high']);
const VALID_POLLUTION_TYPES = new Set([
  'Plastic waste dumping',
  'Open sewage / drainage',
  'Construction debris',
  'Industrial effluent',
  'Air pollution source',
  'Water body contamination',
  'Other',
]);

function hashIp(ip) {
  if (!ip) return null;
  return crypto.createHash('sha256').update(ip).digest('hex');
}

// POST /api/reports — submit a new pollution report.
// multipart/form-data with fields: locationName, landmark, pollutionType,
// severity, description, reporterName, reporterContact, lat, lon
// and 1-10 files under the "photos" field.
router.post('/', uploadReportPhotos, asyncHandler(async (req, res) => {
  const {
    locationName,
    landmark,
    pollutionType,
    severity,
    description,
    reporterName,
    reporterContact,
    lat,
    lon,
  } = req.body || {};

  const files = req.files || [];

  // Validation mirrors the rules already enforced client-side, but the
  // server must never trust the client, so we re-check everything here.
  if (!locationName || !locationName.trim()) {
    throw new ApiError(400, 'Location / area name is required.');
  }
  if (!pollutionType || !VALID_POLLUTION_TYPES.has(pollutionType)) {
    throw new ApiError(400, 'A valid pollution type is required.');
  }
  if (!severity || !VALID_SEVERITIES.has(severity)) {
    throw new ApiError(400, 'A valid severity level (low, med, high) is required.');
  }
  if (files.length === 0) {
    throw new ApiError(400, 'At least one photo of the site is required.');
  }

  const parsedLat = lat !== undefined && lat !== '' ? parseFloat(lat) : null;
  const parsedLon = lon !== undefined && lon !== '' ? parseFloat(lon) : null;
  if (lat !== undefined && lat !== '' && Number.isNaN(parsedLat)) {
    throw new ApiError(400, 'Latitude must be a number.');
  }
  if (lon !== undefined && lon !== '' && Number.isNaN(parsedLon)) {
    throw new ApiError(400, 'Longitude must be a number.');
  }

  const ipHash = hashIp(req.ip);

  const report = await withTransaction(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO reports
        (location_name, landmark, pollution_type, severity, description,
         reporter_name, reporter_contact, lat, lon, ip_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING id, status, created_at`,
      [
        locationName.trim(),
        landmark ? landmark.trim() : null,
        pollutionType,
        severity,
        description ? description.trim() : null,
        reporterName ? reporterName.trim() : null,
        reporterContact ? reporterContact.trim() : null,
        parsedLat,
        parsedLon,
        ipHash,
      ]
    );
    const reportRow = rows[0];

    for (const file of files) {
      await client.query(
        `INSERT INTO report_photos (report_id, filename, original_name, mime_type, size_bytes)
         VALUES ($1,$2,$3,$4,$5)`,
        [reportRow.id, file.filename, file.originalname, file.mimetype, file.size]
      );
    }

    return reportRow;
  });

  res.status(201).json({
    message: 'Report submitted successfully. Our team will review and map it within 24 hours.',
    report: {
      id: report.id,
      status: report.status,
      createdAt: report.created_at,
      photoCount: files.length,
    },
  });
}));

// GET /api/reports — list reports (public, read-only view).
// Supports ?status=pending|verified|in_progress|resolved|rejected
router.get('/', asyncHandler(async (req, res) => {
  const { status } = req.query;
  const params = [];
  let where = '';
  if (status) {
    params.push(status);
    where = `WHERE r.status = $${params.length}`;
  }

  const { rows } = await query(
    `SELECT r.id, r.location_name, r.landmark, r.pollution_type, r.severity,
            r.description, r.status, r.lat, r.lon, r.created_at,
            COALESCE(
              json_agg(
                json_build_object('id', p.id, 'url', '/uploads/' || p.filename)
              ) FILTER (WHERE p.id IS NOT NULL), '[]'
            ) AS photos
     FROM reports r
     LEFT JOIN report_photos p ON p.report_id = r.id
     ${where}
     GROUP BY r.id
     ORDER BY r.created_at DESC
     LIMIT 100`,
    params
  );
  res.json({ reports: rows });
}));

// GET /api/reports/:id — single report detail, including photos.
router.get('/:id', asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT r.*,
            COALESCE(
              json_agg(
                json_build_object('id', p.id, 'url', '/uploads/' || p.filename, 'originalName', p.original_name)
              ) FILTER (WHERE p.id IS NOT NULL), '[]'
            ) AS photos
     FROM reports r
     LEFT JOIN report_photos p ON p.report_id = r.id
     WHERE r.id = $1
     GROUP BY r.id`,
    [req.params.id]
  );
  if (rows.length === 0) throw new ApiError(404, 'Report not found.');
  res.json({ report: rows[0] });
}));

module.exports = router;
