const express = require('express');
const { query, withTransaction } = require('../db/pool');
const { asyncHandler, ApiError } = require('../middleware/errors');

const router = express.Router();

// GET /api/campaigns — list campaigns, active/upcoming first, then by date.
router.get('/', asyncHandler(async (req, res) => {
  const { status } = req.query;
  const params = [];
  let where = "WHERE status != 'cancelled'";
  if (status) {
    params.push(status);
    where = `WHERE status = $${params.length}`;
  }

  const { rows } = await query(
    `SELECT id, title, organizer, status, event_date, start_time, end_time, address,
            coordinator_phone, volunteers_needed, volunteers_registered,
            register_url, map_url, open_to_all
     FROM campaigns
     ${where}
     ORDER BY (status = 'active') DESC, event_date ASC`,
    params
  );
  res.json({ campaigns: rows });
}));

// GET /api/campaigns/:id — single campaign detail.
router.get('/:id', asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT * FROM campaigns WHERE id = $1', [req.params.id]);
  if (rows.length === 0) throw new ApiError(404, 'Campaign not found.');
  res.json({ campaign: rows[0] });
}));

// POST /api/campaigns/:id/register — register a volunteer for a campaign
// directly through our own API (in addition to the external Google Form link).
// Body: { name, contact }
router.post('/:id/register', asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, contact } = req.body || {};

  if (!name || typeof name !== 'string' || !name.trim()) {
    throw new ApiError(400, 'Name is required.');
  }
  if (!contact || typeof contact !== 'string' || !contact.trim()) {
    throw new ApiError(400, 'Contact (phone or email) is required.');
  }

  const result = await withTransaction(async (client) => {
    const { rows: campaignRows } = await client.query(
      'SELECT id, volunteers_needed, volunteers_registered, status FROM campaigns WHERE id = $1 FOR UPDATE',
      [id]
    );
    if (campaignRows.length === 0) throw new ApiError(404, 'Campaign not found.');

    const campaign = campaignRows[0];
    if (campaign.status === 'cancelled' || campaign.status === 'completed') {
      throw new ApiError(400, `This campaign is ${campaign.status} and is no longer accepting registrations.`);
    }
    if (
      campaign.volunteers_needed != null &&
      campaign.volunteers_registered >= campaign.volunteers_needed
    ) {
      throw new ApiError(409, 'This campaign has already reached its volunteer capacity.');
    }

    const { rows: regRows } = await client.query(
      `INSERT INTO campaign_registrations (campaign_id, name, contact)
       VALUES ($1, $2, $3) RETURNING id, created_at`,
      [id, name.trim(), contact.trim()]
    );

    const { rows: updatedCampaign } = await client.query(
      `UPDATE campaigns SET volunteers_registered = volunteers_registered + 1
       WHERE id = $1 RETURNING volunteers_registered, volunteers_needed`,
      [id]
    );

    return { registration: regRows[0], campaign: updatedCampaign[0] };
  });

  res.status(201).json({
    message: 'Registered successfully. See you at the clean-up!',
    ...result,
  });
}));

module.exports = router;
