const express = require('express');
const { query } = require('../db/pool');
const { asyncHandler } = require('../middleware/errors');

const router = express.Router();

// GET /api/hotspots — list active pollution hotspots, high severity first.
router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT id, name, description, severity, created_at
     FROM hotspots
     WHERE active = TRUE
     ORDER BY (severity = 'high') DESC, created_at DESC`
  );
  res.json({ hotspots: rows });
}));

module.exports = router;
