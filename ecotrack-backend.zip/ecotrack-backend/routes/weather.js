const express = require('express');
const { query } = require('../db/pool');
const { asyncHandler } = require('../middleware/errors');

const router = express.Router();

const CACHE_TTL_MS = (parseInt(process.env.WEATHER_CACHE_TTL_SECONDS || '600', 10)) * 1000;
let cache = { data: null, fetchedAt: 0 };

async function fetchWeatherForLocality(loc) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}&current=temperature_2m,apparent_temperature,precipitation,weather_code,relative_humidity_2m,wind_speed_10m&wind_speed_unit=kmh&timezone=Asia/Kolkata`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Open-Meteo responded ${r.status} for ${loc.name}`);
  const d = await r.json();
  return { ...loc, weather: d.current, fetchedAt: new Date().toISOString() };
}

// GET /api/weather — current conditions for every active locality.
// Cached server-side for WEATHER_CACHE_TTL_SECONDS so repeated page loads
// don't hammer Open-Meteo. Pass ?refresh=1 to bypass the cache.
router.get('/', asyncHandler(async (req, res) => {
  const forceRefresh = req.query.refresh === '1';
  const isFresh = Date.now() - cache.fetchedAt < CACHE_TTL_MS;

  if (cache.data && isFresh && !forceRefresh) {
    return res.json({ cached: true, localities: cache.data });
  }

  const { rows: localities } = await query(
    'SELECT id, name, lat, lon FROM localities WHERE active = TRUE ORDER BY display_order ASC'
  );

  const results = await Promise.allSettled(localities.map(fetchWeatherForLocality));

  const localitiesOut = results.map((r, i) => {
    if (r.status === 'fulfilled') return r.value;
    return { ...localities[i], weather: null, error: 'Data unavailable' };
  });

  cache = { data: localitiesOut, fetchedAt: Date.now() };
  res.json({ cached: false, localities: localitiesOut });
}));

module.exports = router;
