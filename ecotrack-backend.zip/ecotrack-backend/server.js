require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const { notFoundHandler, errorHandler } = require('./middleware/errors');
const { UPLOAD_DIR } = require('./middleware/upload');

const weatherRoutes = require('./routes/weather');
const hotspotsRoutes = require('./routes/hotspots');
const campaignsRoutes = require('./routes/campaigns');
const reportsRoutes = require('./routes/reports');
const workshopRequestsRoutes = require('./routes/workshop-requests');

const app = express();
const PORT = process.env.PORT || 3000;

// Trust the first proxy hop (needed for correct req.ip behind a load balancer / Nginx).
app.set('trust proxy', 1);

// --- Security & infra middleware ---------------------------------------
app.use(helmet({
  // Uploaded images are served cross-origin to the frontend, so relax CORP.
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

const allowedOrigins = (process.env.CORS_ORIGIN || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

app.use(cors({
  origin: allowedOrigins.length > 0 ? allowedOrigins : true,
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
}));

app.use(compression());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// General API rate limit: generous, just to blunt abuse/scraping.
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', generalLimiter);

// Tighter limit specifically on report submission to deter spam/flooding,
// since each submission writes files to disk and rows to the DB.
const reportSubmitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many reports submitted from this network. Please try again later.' },
});
app.use('/api/reports', (req, res, next) => {
  if (req.method === 'POST') return reportSubmitLimiter(req, res, next);
  next();
});

// --- Static file serving for uploaded report photos ---------------------
app.use('/uploads', express.static(UPLOAD_DIR, {
  maxAge: '7d',
  // Photos are user-uploaded JPG/PNG/WEBP only; never execute as scripts.
  setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff'),
}));

// --- Health check ---------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// --- API routes -----------------------------------------------------------
app.use('/api/weather', weatherRoutes);
app.use('/api/hotspots', hotspotsRoutes);
app.use('/api/campaigns', campaignsRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/workshop-requests', workshopRequestsRoutes);

// --- Optionally serve the static frontend file itself ---------------------
// If you drop ecotrack_goregaon.html into a `public/` folder next to this
// server, it will be served at the site root. Otherwise this is a no-op
// and the frontend can be hosted separately (just point it at this API's URL).
app.use(express.static(path.join(__dirname, 'public')));

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`EcoTrack Goregaon backend listening on port ${PORT}`);
});

module.exports = app;
