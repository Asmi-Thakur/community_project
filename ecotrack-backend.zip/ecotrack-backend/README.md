# EcoTrack Goregaon — Backend

A Node.js + Express + PostgreSQL backend for the EcoTrack Goregaon dashboard. It replaces the original frontend-only mock behavior (hardcoded campaigns/hotspots, a report form that just showed a fake success message) with a real API: pollution reports are persisted with uploaded photos, campaign volunteer counts update for real, and hotspots/localities are data-driven instead of baked into the HTML.

## What's included

```
ecotrack-backend/
├── server.js                  # Express app entry point
├── db/
│   ├── pool.js                 # PostgreSQL connection pool
│   ├── schema.sql               # Table definitions
│   ├── migrate.js               # Runs schema.sql
│   └── seed.js                   # Seeds localities/hotspots/campaigns with the original site's data
├── middleware/
│   ├── errors.js                  # Centralized error handling + asyncHandler wrapper
│   └── upload.js                   # Multer config for report photo uploads
├── routes/
│   ├── weather.js                   # Proxies + caches Open-Meteo per locality
│   ├── hotspots.js                   # Pollution hotspot list
│   ├── campaigns.js                   # Campaign list + volunteer registration
│   ├── reports.js                      # Pollution report submission + listing
│   └── workshop-requests.js             # Composting workshop request form
├── public/
│   └── index.html                        # The original frontend, now wired to call this API
├── uploads/                                # Where report photos are stored on disk
├── .env.example
└── package.json
```

`public/index.html` is the frontend you uploaded, modified only in the `<script>` section so the Weather, Campaigns, and Hotspots tabs fetch live data from this API instead of using hardcoded arrays, and the Report form actually uploads to the server instead of just showing a success banner. All HTML/CSS is untouched.

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Create a PostgreSQL database

```sql
CREATE USER ecotrack_user WITH PASSWORD 'changeme';
CREATE DATABASE ecotrack_goregaon OWNER ecotrack_user;
```

### 3. Configure environment

```bash
cp .env.example .env
# then edit .env — at minimum set DATABASE_URL and CORS_ORIGIN
```

### 4. Run migrations and seed data

```bash
npm run migrate
npm run seed
```

The seed script inserts the same localities, hotspots, and 4 campaigns that were hardcoded in the original HTML, so the site looks identical on first load — except the data now lives in the database and can be changed without touching code.

### 5. Start the server

```bash
npm start          # production
npm run dev         # auto-restarts on file changes
```

The frontend is served at `http://localhost:3000/` (from `public/index.html`), and the API lives under `http://localhost:3000/api/*`.

If you'd rather host the frontend separately (e.g. a different static host), set `window.API_BASE = 'https://your-api-domain.com'` in a `<script>` tag before the main script in the HTML, and make sure that domain is in `CORS_ORIGIN`.

## API reference

All responses are JSON unless otherwise noted.

### Weather
- `GET /api/weather` — current conditions for every active locality, proxied from Open-Meteo and cached server-side for `WEATHER_CACHE_TTL_SECONDS` (default 10 min). Add `?refresh=1` to force a fresh fetch.

### Hotspots
- `GET /api/hotspots` — active pollution hotspots, high severity first.

### Campaigns
- `GET /api/campaigns` — list campaigns (optionally `?status=active|upcoming|completed|cancelled`).
- `GET /api/campaigns/:id` — single campaign.
- `POST /api/campaigns/:id/register` — register a volunteer. Body: `{ "name": "...", "contact": "..." }`. Rejects once `volunteers_registered` reaches `volunteers_needed`.

### Reports
- `POST /api/reports` — submit a pollution report. `multipart/form-data` with fields `locationName`, `landmark`, `pollutionType`, `severity` (`low`/`med`/`high`), `description`, `reporterName`, `reporterContact`, optional `lat`/`lon`, and 1–10 files under `photos` (JPG/PNG/WEBP, ≤5MB each — both limits configurable via `.env`). Rate-limited to 10 submissions/hour per IP.
- `GET /api/reports` — list recent reports (optionally `?status=pending|verified|in_progress|resolved|rejected`), each with its photo URLs.
- `GET /api/reports/:id` — single report detail.

### Workshop requests
- `POST /api/workshop-requests` — request a free composting workshop. Body: `{ "societyName", "contactName", "contactEmail"?, "contactPhone"?, "preferredDate"?, "notes"? }` (need at least one of email/phone).

### Health
- `GET /api/health` — `{ status: "ok", timestamp }`.

## Design notes

**Why a real backend at all, given the original was a NEP 2020 student project demo?** The original report form validated input but then just flashed a success banner and discarded everything — no report ever reached anyone. This backend makes that real: photos land on disk, a row goes into `reports`, and there's a path to actually act on submissions (the `GET /api/reports` endpoints exist so a future admin view or moderation script has something to query).

**Weather proxying.** The original called Open-Meteo directly from the browser on every page load for all 8 localities. This backend proxies it server-side with a short cache, so repeat visits within the cache window don't hit Open-Meteo again, and the locality list can be edited in the `localities` table instead of in JavaScript.

**Campaign registration vs. the Google Forms.** The existing "Register Now" buttons linking to Google Forms are left in place — that's an external system this backend doesn't control. A second button, "Register via EcoTrack," was added that hits `POST /api/campaigns/:id/register` so volunteer counts shown on the page are live and capacity limits are enforced, without removing the original registration path organizers may already depend on.

**Photo storage.** Stored on local disk under `uploads/`, served back via `/uploads/<filename>` with `X-Content-Type-Options: nosniff` and an allow-list of image MIME types so this can't become a place to host arbitrary files. For a multi-server deployment, swap `middleware/upload.js`'s disk storage for an S3/GCS adapter — the rest of the app only deals with `filename`/`mime_type`/`size_bytes`, so the change is contained to that one file plus how `report_photos.filename` gets resolved to a URL.

**Validation duplication.** The frontend's client-side checks (required fields, severity selection, at least one photo) are intentionally re-implemented server-side in `routes/reports.js`, since client-side validation alone can always be bypassed by anyone calling the API directly.

## Things you'll likely want to change before going to production

- `CORS_ORIGIN` and `DATABASE_URL` in `.env` for your actual deployment.
- The campaign registration "modal" currently uses `prompt()` for simplicity — fine for a quick build, but a real form/modal would feel less jarring.
- There's no authentication anywhere — admin-style endpoints (changing report status, adding campaigns) weren't built per your request, but if you add them later, put them behind auth before deploying.
- Consider a periodic job to delete `report_photos` files for reports older than some retention window, since nothing currently prunes the `uploads/` folder.
